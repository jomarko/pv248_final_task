from setuptools import setup

setup(name='regexp_server',
      version='1.0',
      py_modules=['regexp_server']
      )